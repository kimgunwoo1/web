from django.contrib import admin
from . models import MyBoard, MyMember

admin.site.register(MyBoard)
admin.site.register(MyMember)