onload = function(){
    alert('style')
}