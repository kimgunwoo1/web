function mytest() {
    alert('외부 파일에서 실행 됨')

}

// window.onload
onload = function () {
    alert('page 로딩이 완료')
}